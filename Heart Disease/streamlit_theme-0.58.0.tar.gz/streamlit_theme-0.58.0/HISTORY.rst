=======
History
=======

0.58.0 (2020-04-28)
-------------------

* First release on PyPI.
