=====
Usage
=====

To style your Streamlit app::

    import streamlit as st
    import streamlit_theme as stt

    stt.set_theme({'primary': '#1b3388'})
    st.title('My themed app')
