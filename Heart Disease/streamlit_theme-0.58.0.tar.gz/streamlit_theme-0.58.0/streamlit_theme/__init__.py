"""Top-level package for Streamlit Theme."""

__author__ = """Sam Dobson"""
__email__ = 'sjd333@gmail.com'
__version__ = '0.58.0'

from .streamlit_theme import set_theme
