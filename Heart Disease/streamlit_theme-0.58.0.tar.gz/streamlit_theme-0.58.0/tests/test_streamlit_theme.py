#!/usr/bin/env python

"""Tests for `streamlit_theme` package."""


import unittest

from streamlit_theme import streamlit_theme


class TestStreamlit_theme(unittest.TestCase):
    """Tests for `streamlit_theme` package."""

    def setUp(self):
        """Set up test fixtures, if any."""

    def tearDown(self):
        """Tear down test fixtures, if any."""

    def test_000_something(self):
        """Test something."""
